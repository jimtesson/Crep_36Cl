function [ ] = GetAgesf( name )
% Function of the crep program that calculates exposure ages

% Open paths and load data
addpath Functions
addpath Constants
addpath jsonlab
load GMDB
load OtherCst
%name=strrep(name,"\\","/"); OCTAVE !!!!!
name=strrep(name,'\\','/'); %MATLAB !!!!!
% Retreive json file
Data=loadjson(name);

% Load the parameters
Nucl=Data.Nucl;
Scheme=Data.Scheme;
Atm=Data.Atm;
if Atm==0;
    load ERA40
else
    meanP=[];
    meanT=[];
    ERA40lat=[];
    ERA40lon=[];
end
if length(Data.GMDB)==1;
    NumGMDB=Data.GMDB;
    if NumGMDB==1;
        SelGMDB=GMDB.Musch;
    elseif NumGMDB==2;
        SelGMDB=GMDB.GLOPIS;
    else
        SelGMDB=GMDB.LSD;
    end
else
    NumGMDB=4;
    SelGMDB=Data.GMDB;
end
% mu=OtherCst.Dens/OtherCst.Attlgth; % Mu becomes a vector with the user
% input
Attlg=OtherCst.Attlgth;
tBe=OtherCst.tBe;
Lambda10Be=log(2)/tBe;
SelPR=Data.PR;

% Set the waitbar
% h = waitbar(0,'Calculating');

% Get user data in right form
VecName=Data.Samples';
VecLat=Data.Lat';
[NbSpl,~]=size(VecLat);
VecLon=Data.Lon';
VecAlt=Data.Alt';
VecConc=Data.NuclCon';
VecErrConc=Data.NuclErr';
VecThick=Data.Thick';
VecShield=Data.Shield';
VecErosion=Data.Eros';
VecDens=Data.Dens';
VecMu=VecDens./Attlg;

% Formatting Outputs
ExitMat=zeros(NbSpl,4);
CellPDF=cell(1,2*NbSpl);
ErrCol=zeros(NbSpl,1);
StatCell=cell(NbSpl,1);


% waitbar(1/(NbSpl+3))

% Calculating
for i=1:NbSpl;
    % waitbar((i+1)/(NbSpl+3))
    ErrPRflag=0;
    % Preliminary corrections
    ThickCorr=(Attlg/(VecThick(i)*VecDens(i)))*(1-exp(-1*(VecThick(i)*VecDens(i))/Attlg));
    CorrConc=VecConc(i)/(ThickCorr*VecShield(i));
    
    if Scheme==1; % Lal-Stone Scaling
        
        % CosmoAge calculation
        StoneFactor=StoneFactV2(VecLat(i),VecLon(i),VecAlt(i),Atm);
        if Nucl==3;
            if VecErosion(i)==0;
                CosmoAge=CorrConc/(SelPR(1)*1000*StoneFactor);
            else
                CosmoAge=(-1/(VecMu(i)*VecErosion(i)))*log(1-(VecMu(i)*VecErosion(i)*CorrConc/(SelPR(1)*StoneFactor)))/1000;
                if isreal(CosmoAge)==0;
                    ErrPRflag=1;
                    CosmoAge=-100;
                end
            end
        elseif Nucl==10;
            CosmoAge=(-1/(Lambda10Be+VecMu(i)*VecErosion(i)))*log(1-((Lambda10Be+VecMu(i)*VecErosion(i))*CorrConc/(SelPR(1)*StoneFactor)))/1000;
            if isreal(CosmoAge)==0;
                ErrPRflag=1;
                CosmoAge=-100;
            end
        end
        ErrCosmo=CosmoAge*VecErrConc(i)/VecConc(i);
        
        % Time-dependent integration-correction
        [Age,Err,Err2,X,Y]=AgeCosmoAgeReelV22(CosmoAge,ErrCosmo,(SelPR(2)/SelPR(1)),VecLat(i),VecLon(i),VecAlt(i),SelGMDB,Atm,ERA40lat,ERA40lon,meanP,meanT);
        
    else % LSD Scaling
        
        if NumGMDB==3;
            % CosmoAge calculation
            [~,SF]=LSDv9(VecLat(i),VecLon(i),VecAlt(i),Atm,0,-1,Nucl,NumGMDB);
            if Nucl==3;
                if VecErosion(i)==0;
                    CosmoAge=CorrConc/(SelPR(1)*1000*SF);
                else
                    CosmoAge=(-1/(VecMu(i)*VecErosion(i)))*log(1-(VecMu(i)*VecErosion(i)*CorrConc/(SelPR(1)*SF)))/1000;
                    if isreal(CosmoAge)==0;
                        ErrPRflag=1;
                        CosmoAge=-100;
                    end
                end
            else
                CosmoAge=(-1/(Lambda10Be+VecMu(i)*VecErosion(i)))*log(1-((Lambda10Be+VecMu(i)*VecErosion(i))*CorrConc/(SelPR(1)*SF)))/1000;
                if isreal(CosmoAge)==0;
                    ErrPRflag=1;
                    CosmoAge=-100;
                end
            end
            ErrCosmo=CosmoAge*VecErrConc(i)/VecConc(i);
            % Time corrected age calculation
            [Age,Err,Err2,X,Y] = AgeCosmoAgeReelLSD(CosmoAge,ErrCosmo,(SelPR(2)/SelPR(1)),VecLat(i),VecLon(i),VecAlt(i),NumGMDB,Atm,Nucl);
        else
            % CosmoAge calculation
            [~,SF]=LSDv9(VecLat(i),VecLon(i),VecAlt(i),Atm,0,-1,Nucl,SelGMDB);
            if Nucl==3;
                if VecErosion(i)==0;
                    CosmoAge=CorrConc/(SelPR(1)*1000*SF);
                else
                    CosmoAge=(-1/(VecMu(i)*VecErosion(i)))*log(1-(VecMu(i)*VecErosion(i)*CorrConc/(SelPR(1)*SF)))/1000;
                    if isreal(CosmoAge)==0;
                        ErrPRflag=1;
                        CosmoAge=-100;
                    end
                end
            else
                CosmoAge=(-1/(Lambda10Be+VecMu(i)*VecErosion(i)))*log(1-((Lambda10Be+VecMu(i)*VecErosion(i))*CorrConc/(SelPR(1)*SF)))/1000;
                if isreal(CosmoAge)==0;
                    ErrPRflag=1;
                    CosmoAge=-100;
                end
            end
            ErrCosmo=CosmoAge*VecErrConc(i)/VecConc(i);
            % Time corrected age calculation
            [Age,Err,Err2,X,Y] = AgeCosmoAgeReelLSD(CosmoAge,ErrCosmo,(SelPR(2)/SelPR(1)),VecLat(i),VecLon(i),VecAlt(i),SelGMDB,Atm,Nucl);
        end
    end
    
    ExitMat(i,2)=Age;
    ExitMat(i,3)=Err;
    ExitMat(i,4)=Err2;
    CellPDF{2*i-1}=X;
    CellPDF{2*i}=Y;
    
    % Look if there is a problem with the length of the database
    if isempty(X)==1;
        ErrCol(i)=1;
        if ErrPRflag==1;
            Mess=sprintf('Production rate too low');
        elseif isnan(Age)==1;
            Mess=sprintf('Sample too old for the Geomagnetic database');
            %         elseif Age<2; Chope if to young ?
            %             Mess=sprintf('Sample too young to provide probability density distribution');
        else
            Mess=sprintf('Relative error bar too large to provide probability density function (excursion in negative ages or ages older than the Geomagnetic database)');
        end
    else
        Mess=sprintf('Ok');
    end
    StatCell{i}=Mess;
    
    % Store the time correctd scaling factor
    if Nucl==3;
        SFtc=CorrConc/(SelPR(1)*Age*1000);
    else
        SFtc=CorrConc*Lambda10Be/(SelPR(1)*(1-exp(-Lambda10Be*Age*1000)));
    end
    ExitMat(i,1)=SFtc;
end

MatPDF=CreeMatCP4(CellPDF,0.01);
ColSum=sum(MatPDF(:,2:end),2);
ToExit= ColSum==0;
MatPDF(ToExit,:)=[];
% waitbar((NbSpl+2)/(NbSpl+3))

% Fill PDFtable
VecName2=cell(1,NbSpl);
ifill=1;
for i=1:NbSpl;
    if ErrCol(i)==0;
        VecName2{ifill}=VecName{i};
        ifill=ifill+1;
    end
end
VecName2(ifill:end)=[];

% Density functions to be displayed
PDFdisp=cell(1,(ifill-1));
nbsigdisp=6;
nbptdisp=500;

if ifill>=2;
    for i=1:ifill-1;
        [~,~,Mediane,Err1SigInf,Err1SigSup,~,~]=ParamDistribV11(CellPDF{2*i-1},CellPDF{2*i});
        Binf=max(0,max((Mediane-nbsigdisp*Err1SigInf),CellPDF{2*i-1}(1)));
        Bsup=min(Mediane+nbsigdisp*Err1SigSup,CellPDF{2*i-1}(end));
        ti=linspace(Binf,Bsup,nbptdisp);
        pdfi=interp1(CellPDF{2*i-1},CellPDF{2*i},ti);
        PDFdisp{i}=[ti' pdfi'];
    end
else
    PDFdisp=[];
end

% Prepare Output
DataOut.Samples=Data.Samples;
DataOut.ScalFact=ExitMat(:,1)';
DataOut.Ages=ExitMat(:,2)';
DataOut.AgesErr=ExitMat(:,3)';
DataOut.AgesErr2=ExitMat(:,4)';
DataOut.Status=StatCell';
DataOut.TimeV=MatPDF(:,1)';
DataOut.SamplePDF=VecName2;
DataOut.PDF=MatPDF(:,2:end)';
DataOut.PDFdisp=PDFdisp;

% Write json
DataOut=savejson(name,DataOut);
NameOut=strcat(name(1:end-2),'out');
fileID=fopen(NameOut,'w');
fprintf(fileID,'%s',DataOut);
fclose(fileID);

% Closing
waitbar(1/1)
% close(h)

end
